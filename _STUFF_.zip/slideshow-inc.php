 <? /*  
<style>
	#slideshow{ width:95% !important}
</style> 
    
    <div id="slide-show-wrap"   align="center" >
        <div class="slideshow"  style="width:75% !important;">
                <img src="/slideshow/slideshow1.jpg" style="width:100% !important" />
                <img src="/slideshow/slideshow2.jpg" style="width:100% !important" />
                <img src="/slideshow/slideshow3.jpg" style="width:100% !important" />
        </div>
    </div>
*/ ?>