<br />

<div align="center" style="color:#333; background-color:#fff">
<a href="/register.php" class="navlink">sign up</a> 
<a href="/login.php" class="navlink">login</a> 
</div>