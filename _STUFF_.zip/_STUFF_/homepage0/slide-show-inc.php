 

 


    <div id="slide-show-wrap">
        <div class="slideshow"  style="background-color:#414142 !important;">
            <img src="http://stevegothelf.com/photos/slideshow_1402102449.jpg"  />
            <img src="http://stevegothelf.com/photos/Edgewood_226_view1-1280x958.jpg"  />
            <img src="http://stevegothelf.com/photos/slideshow_1403213892_1687961.jpg"  />
            <img src="http://stevegothelf.com/photos/Broadway_2950_e08-1280x800.jpg"  />
            <img src="http://stevegothelf.com/photos/Livingrm1-1280x800.jpg"  />
        </div>
    </div>
