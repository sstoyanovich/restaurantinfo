<table width="400" border="0" bordercolor="#ffffff" style="border-collapse:collapse" cellspacing="0" cellpadding="0">
<tr style="background-image:url(/images/layout/dashboard-header-bkgnd2.png); background-repeat:no-repeat">
<td align="center" height="26">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
    <td align="center" width="25%" height="25%" >&nbsp;</td>
    <td align="center" width="50%" style="color:#fff;">&nbsp;<strong>Sales Summary</strong></td>
    <td align="center" width="25%" ><a href="my-sales.php" style="color:#FF9; text-decoration:underline">Details</a> &nbsp;</td>
    </tr>
    </table>
</td>
</tr>
</table>
<table width="400" border="1" bordercolor="#555555" style="border-collapse:collapse; font-size:12px; background-color:#FFF; color:#000; box-shadow: 5px 5px 5px #888888;  margin-bottom:7px;" cellspacing="0" cellpadding="4">
<tr style="background-color:#f8f8f8; color:#333">
  <td align="left" valign="top" height="200" width="100%"><? $dashboard_summary = 1; require("my-sales-inc.php"); ?></td>
</tr>
</table> 
