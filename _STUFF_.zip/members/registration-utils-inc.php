<?
function get_reg_code_fname($num)
{
	switch ($num)
	{
		case 0:	 $fname = "78903982767890876789875899"; break;
		case 1:	 $fname = "80524782369957905904739083"; break;
		case 2:	 $fname = "12405606481724957263895644"; break;
		case 3:	 $fname = "78902356139364034746649690"; break;
		case 4:	 $fname = "993470623763479t6847839734"; break;
		case 5:	 $fname = "13095850348767603825834458"; break;
		case 6:	 $fname = "9274249257825892378940t878"; break;
		case 7:	 $fname = "67345458965345974958476969"; break;
		case 8:	 $fname = "57348734873524424536485690"; break;
		case 9:	 $fname = "87398738384597684749560784"; break;
		default: $fname = "50854933940589057905049755"; break;
	}
	return $fname;	
}
